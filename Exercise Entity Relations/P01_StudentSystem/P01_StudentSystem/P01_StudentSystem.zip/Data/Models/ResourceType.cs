﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P01_StudentSystem.Data.Models
{
    public enum  ResourceType
    {
        Video = 10,
        Presentation = 20,
        Document = 30,
        Other = 40

    }
}
